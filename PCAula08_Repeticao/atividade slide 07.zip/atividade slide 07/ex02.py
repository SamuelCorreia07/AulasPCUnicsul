# Soma 10 num reais
soma = 0
for i in range(10):
    num = float(input("Digite um número real: "))
    soma = soma + num

print("O resultado da soma é: ", soma)