# media duas notas 10 alunos while
contador = 1
while contador <= 10:
    nota1 = float(input("Digite a primeira nota: "))
    nota2 = float(input("Digite a segunda nota: "))
    media = (nota1 + nota2)/2
    print("A média é %.2f" %media)
    contador = contador + 1