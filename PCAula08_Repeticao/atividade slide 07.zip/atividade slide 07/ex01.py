# Tabuada
num=int(input("Digite um numero inteiro: "))
for i in range (11):
    print("%d * %d = %d" %(num, i, num*i))