def media(a, b):
    return (a+b) / 2
# Para ver os resultados das chamadas
print(media(0, 5))
print(media(2, 4))