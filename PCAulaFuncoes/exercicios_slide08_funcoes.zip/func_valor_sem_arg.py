def exibir_idade(nome, idade=40):
    print(f"{nome} tem {idade} anos.")

exibir_idade("Carlos")