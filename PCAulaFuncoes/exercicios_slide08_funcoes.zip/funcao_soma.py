def soma(a,b):
    # 'a' e 'b' são parâmetros
    resultado = a + b
    print(resultado)

soma(5,3)
# 5 e 3 são argumentos