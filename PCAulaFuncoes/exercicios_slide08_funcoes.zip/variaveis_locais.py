def area_triangulo(base, altura):
    area = (base * altura) / 2
    return area

print(area_triangulo(4, 6))